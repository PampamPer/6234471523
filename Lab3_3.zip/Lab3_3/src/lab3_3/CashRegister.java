/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author Pampam_per
 */
public class CashRegister {
    private double total1,total2,tax,payment,taxrate;
    public CashRegister(double rate){
        taxrate = rate;
    }
    public void recordPurchase(double price1){
        total1 += price1 ;
    }
    public void recordTaxablePurchase(double price2){
        tax = price2*taxrate; 
        total2 += price2+tax ;
        tax = 0;
    }
    public void enterPayment(double input){
        payment += input ;
    }
    public double getTotalTax(){
        return taxrate ;
    }
    public double giveChange(){
        double change = payment-total1-total2;
        total1 = 0;
        total2 = 0;
        payment = 0;
        return change;
    }
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        CashRegister test = new CashRegister(0.07) ;
        test.recordPurchase(50);
        test.recordPurchase(10);
        test.recordTaxablePurchase(20);
        test.enterPayment(100);
        System.out.println(test.giveChange());
        
        
        
        // TODO code application logic here
    }
    
}
