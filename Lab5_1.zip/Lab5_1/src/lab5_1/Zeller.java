/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_1;

/**
 *
 * @author Pampam_per
 */
public class Zeller {
    private int dayOfMonth; //เก็บวันของเดือน
    private int month; //เก็บเดือน
    private int year; //เก็บป
    
    public Zeller(int d,int mth,int yr){
        dayOfMonth = d;
        month = mth;
        year = yr;
    }
    
    public Day getDayOfWeek(){
        if(month == 1){month = 13;year = year-1;}
        if(month == 2){month = 14;year=year-1;}
        int h,q = dayOfMonth,m=month,k=year%100,j=year/100 ;
        Day a = null;
        h = (q+((26*(m+1))/10)+k+(k/4)+(j/4)+(5*j))%7 ;
        
        switch (h){
            case 0:a= Day.SATURDAY ; break;
            case 1:a= Day.SUNDAY ;break;
            case 2:a= Day.MONDAY ;break;
            case 3:a= Day.TUESDAY ;break;
            case 4:a= Day.WEDNESDAY ;break;
            case 5:a= Day.THURSDAY ;break;
            case 6:a= Day.FRIDAY ;break;
            
        }
        return a;
        
    }
    
    /**
     * @param args the command line arguments
     */
    
}
