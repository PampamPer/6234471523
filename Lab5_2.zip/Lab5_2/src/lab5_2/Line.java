/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_2;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double ;

/**
 *
 * @author Pampam_per
 */
public class Line {
    Point2D.Double p1,p2;
    
    
    private double M,c,X;
    
    private boolean XCheck = false;
    
    public Line(double x, double y, double m){
        M = m;
        c = y-(m*x);}
    public Line(double x1, double y1, double x2, double y2){
        p1 = new Point2D.Double(x1,y1);
        p2 = new Point2D.Double(x2,y2);
        M = (y2-y1)/(x2-x1);
        c = y1-(M*x1);
        }
    public Line(double m, double b){
        M=m;
        c=b;
    }
    public Line(double a) {
        M = 1;
        c = 0;
        X  = a;
        XCheck = true;
        }

    public boolean isParallel(Line line){
        if(this.M == line.M){return true;}
        else{return false;}
     }
    public boolean equals(Line line){
        if(this.M == line.M && this.c == line.c){return true;}
        else{return false;}
    }
    public boolean isIntersect(Line line){
     if(this.isParallel(line)==false){return true;}
     else{return false;}
    }
    public Point2D.Double getIntersectionPoint(Line line){
        
        if(this.isParallel(line)==false){
            if(this.XCheck == true){
                double x = this.X ;
                double y = (line.M*x)+line.c;
                Point2D.Double point = new Point2D.Double(x,y);
                return point;}
                
            
            else if(line.XCheck==true){
                double x = line.X ;
                double y = (this.M*x)+this.c;
                Point2D.Double point = new Point2D.Double(x,y);
                return point;
            
            }
            
            else if(this.M==0){
                double x = (this.c-line.c)/line.M ;
                double y = this.c;
                Point2D.Double point = new Point2D.Double(x,y);
                return point;
                
            }
            
            else if(line.M==0){
                double x = (line.c-this.c)/this.M ;
                double y = line.c;
                Point2D.Double point = new Point2D.Double(x,y);
                return point; }
            
            else if(this.M==0 && line.XCheck==true){
                double x = line.X;
                double y = this.c;
                Point2D.Double point = new Point2D.Double(x,y);
                return point; }
            
            else if(line.M==0 && this.XCheck==true){
                double x = this.X;
                double y = line.c;
                Point2D.Double point = new Point2D.Double(x,y);
                return point; }
            
            
            
            
            else{
                double x = (-1)*(this.c-line.c)/(this.M-line.M) ;
                double y = (this.M*x)+this.c ;
                Point2D.Double point = new Point2D.Double(x,y);
                return point;}
        
    }
        
        else{return null;}
        
    }
}

    
    /**
     * @param args the command line arguments
     */
    
    

