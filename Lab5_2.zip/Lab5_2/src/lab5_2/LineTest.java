/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_2;

import java.awt.geom.Point2D;

/**
 *
 * @author Pampam_per
 */
public class LineTest {
    public void print(Line l1,Line l2){
        Point2D.Double line = l1.getIntersectionPoint(l2);
        System.out.println("Are the two lines equals?: "+l1.equals(l2));
        System.out.println("Are the two lines parallel?: "+l1.isParallel(l2));
        System.out.println("Do the two lines intersect?: "+l1.isIntersect(l2));
        if(line != null){System.out.printf("Point of intersection: %.2f,%.2f \n",line.getX(),line.getY());}}
    
    public static void main(String[] args) {
        LineTest test = new LineTest();
        Line l1 = new Line(0.44,3.4);
Line l2 = new Line(0.44,5);  
        test.print(l1, l2);
        
        
        
        
        
        // TODO code application logic here
    }
}
