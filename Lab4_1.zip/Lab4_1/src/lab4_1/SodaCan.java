/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_1;

/**
 *
 * @author usci
 */
public class SodaCan {
    private double h,r ;
    
    public SodaCan(double x,double y){
        h = x ;
        r = y/2 ;
    }
    public double getVolumn(){
        double v = Math.PI*r*r*h ;
        return v ;
    }
    public double getSurfaceArea(){
        double a = (2*Math.PI*r*h)+(2*Math.PI*r*r) ;
        return a ; 
    }
    /**
     * @param args the command line arguments
     */
    
    
}
