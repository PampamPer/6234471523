package lab4_1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner ;
/**
 *
 * @author usci
 */
public class SodaTester {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in) ;
        System.out.print("Enter Height: ");
        double height = input.nextDouble() ;
        System.out.print("Enter diameter: ");
        double diameter = input.nextDouble() ;
        // TODO code application logic here
        SodaCan test = new SodaCan(height,diameter);
        System.out.println("Volumn: "+ test.getVolumn());
        System.out.println("Surface area: "+ test.getSurfaceArea());
         
        
    }
}
