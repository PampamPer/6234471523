/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_3;
    import java.util.GregorianCalendar ;
    import java.util.Calendar ;
/**
 *
 * @author Pampam_per
 */
public class Gregorian {
    GregorianCalendar cal = new GregorianCalendar();
    GregorianCalendar myBirthday = new GregorianCalendar(2001,Calendar.MAY,17);

    public void PrG(GregorianCalendar date){
        int weekday = date.get(Calendar.DAY_OF_WEEK);
        int dayOfMonth = date.get(Calendar.DAY_OF_MONTH); 
        int month = date.get(Calendar.MONTH);
        int year = date.get(Calendar.YEAR);
        System.out.println(weekday+" "+dayOfMonth+" "+month+" "+year);
    
    }
    public static void main(String[] args) {
        Gregorian cal2 = new Gregorian();
        cal2.cal.add(Calendar.DAY_OF_MONTH, 100);
        cal2.myBirthday.add(Calendar.DAY_OF_MONTH, 10000);
        cal2.PrG(cal2.cal);
        cal2.PrG(cal2.myBirthday);
       
        
        
    }
    
}
