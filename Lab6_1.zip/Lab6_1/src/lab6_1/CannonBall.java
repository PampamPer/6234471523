/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_1;

/**
 *
 * @author usci
 */
public class CannonBall {
    
    private double initV; //ความเร็วตั้งต้น
    private double simS; //ระยะทางที่คำนวณได้จากวิธี simulation
    private double simT; //เวลาที่ใช้ในวิธี simulation
    public static final double g = 9.81;
    
    public CannonBall(double v){
        initV = v;
        }
    
    
    public void simulatedFlight(){
    
        System.out.println();
    }
    
    public double calculusFlight(double t){
        double s = 0;
        return s;} //คำนวณระยะทางที่ลูกกระสุนปืนใหญ่เคลื่อนที่ไปได้ หากใช้ระยะเวลา t
    public double getSimulatedTime(){
        double t = 0;
        return t;} //คืนระยะเวลาทั้งหมดที่ใช้จนลูกกระสุนปืนตกกลับลงพื้นในวิธี simulation
    public double getSimulatedDistance(){
        double s = 0;
        return s;}
    
    

    /**
     * @param args the command line arguments
     */
    
    
}
