/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_2;

/**
 *
 * @author Pampam_per
 */
public class Letter {
    
    private String text = "";
    private String send,recieve;
    
    public Letter(String from, String to){
        send = from ;
        recieve = to;
    }
    public void addLine(String line){
        text += line+"\n" ;
        
    }
    public String getText(){
        String letter = "Dear "+recieve+"\n\n"+text+"\nSincerely,\n\n"+send ;
        return letter ;
    }

    /**
     * @param args the command line arguments
     */
    
        
        // TODO code application logic here
    }
    

