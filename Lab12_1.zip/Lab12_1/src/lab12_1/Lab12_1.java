/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_1;

import java.util.Scanner;
import java.io.*;

/**
 *
 * @author Pampam_per
 */
public class Lab12_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
        int sum =0,lines =0,word = 0;
        Scanner sc = new Scanner(System.in);
        String text = sc.nextLine();
        PrintWriter Textfile = new PrintWriter("text.txt");
        
        while(!(text.equals("quit")) ){
            Textfile.println(text);
            text = sc.nextLine();
        }
        
        Textfile.close();
        File file = new File("text.txt");
        Scanner read = new Scanner(file);
        while(read.hasNextLine()){
            String line = read.nextLine();
            sum += line.length();
            word++;
            lines ++;
            for(int i = 0;i < line.length();i++){
                if(line.charAt(i)==' '){
                    word++;
                }
            }
        }
        
        read.close();
        
        System.out.println("Total characters : "+sum);
        System.out.println("Total words : "+word);
        System.out.println("Total lines : "+lines);
        // TODO code application logic here
        
    }
    
}
