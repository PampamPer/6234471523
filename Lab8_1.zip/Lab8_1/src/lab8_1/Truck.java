/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1;

/**
 *
 * @author Pampam_per
 */
class Truck extends Car {
    
    private double M_weight,weight;
    
    public Truck(double gas,double efficiency,double M_weight,double weight){
        super(gas,efficiency);
        this.M_weight = M_weight;
        this.weight = weight;
        if(weight>M_weight){
            this.weight = M_weight;
        }
        
    }
    
    @Override
    public void drive(double distance){
        System.out.println(gas+" "+efficiency+" "+distance);
        
        double x = distance/efficiency;
        
        if(x<gas){
            gas = gas-x ;
        }
        else {
            System.out.println("You can not drive too far,please add gas");
            return;
        }
        
        System.out.println(gas+" "+efficiency+" "+distance);
        
        if(1 <= weight && weight <= 10){
            gas = gas-(x*0.1);
        }
        else if(11 <= weight && weight <= 20){
            gas = gas-(x*0.2);
        }
        else if(20 < weight){
            gas = gas-(x*0.3);
        }
        
        System.out.println(gas+" "+efficiency+" "+distance);
        
        
    } 
}
