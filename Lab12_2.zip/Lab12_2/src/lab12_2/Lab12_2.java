/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_2;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.io.*;
/**
 *
 * @author Pampam_per
 */
public class Lab12_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<String> a = new ArrayList<String>();
        ArrayList<String> w = new ArrayList<String>();
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String text = sc.nextLine();
        String str[] = text.split(" ");
        List<String> al = new ArrayList<String>();
        al = Arrays.asList(str);
        
        System.out.println("Words not contained:");
        
        
        try{
            for(String word:al){
                File file = new File("wordlist.txt");
                Scanner read = new Scanner(file);
                while(read.hasNextLine()){
                    String s = read.nextLine();
                    if(word.equals(s)){
                        w.add(word);
                    }
                }
                read.close();
            }
            
            int j = 0;
            for(int i = 0;i<al.size();i++){
                if(al.size()==w.size()){
                    System.out.println("N/A");
                    break;
                }
                
                if(j>=w.size()){
                    a.add(al.get(i));
                    continue;
                }
                if(!al.get(i).equals(w.get(j))  ){
                        a.add(al.get(i));
                        continue;
                }
                j++;
            }
       }
        
        catch(IOException e){
            System.out.print(e);
        }
        
        if(a.size()!=0){
            for(String i:a){
                System.out.println(i);
            }
        }
    }
    
}
