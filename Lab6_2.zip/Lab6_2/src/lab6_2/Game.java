/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_2;

import java.util.Scanner;
import java.util.Random;
/**
 *
 * @author usci
 */
public class Game {
    private String input;
    private int player;
    private int score_p=0,score_c=0;
    
    public Game(){
       score_p=0;
       score_c=0;
        
    }
        
    
        
    
    public void play(){
      
        Scanner sc = new Scanner(System.in);
        while(Math.abs(score_p-score_c) < 2){
            
            
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            input = sc.nextLine();
            
            if(!input.equals("0") && !input.equals("1") && !input.equals("2")){
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            input = sc.nextLine();
       }
       
       else{
            if(input.equals("0")){
                System.out.println("You enter: ROCK");
                player = Integer.valueOf(input);
                }
            
            if(input.equals("1")){
                System.out.println("You enter: PAPER");
                player = Integer.valueOf(input);
                }
            
            if(input.equals("2")){
                System.out.println("You enter: SCISSORS");
                player = Integer.valueOf(input);
                }
       
       }
            
            Random b = new Random();
        int bot = b.nextInt(3);
        

        
        
        if(bot == 0){
            System.out.println("Computer: ROCK");
            }
            
        if(bot == 1){
            System.out.println("Computer: PAPER");
            }
            
        if(bot == 2){
            System.out.println("Computer: SCISSORS");
            }
            
            
            if(player-bot != 0){
                if(player-bot==1){
                    score_p +=1;
                    System.out.println("You win!");
                    
                }
            
                else if(player-bot==-2){
                    score_p +=1;
                    System.out.println("You win!");
                    
                }
                else if(bot-player==1 || bot-player==-2){
                    score_c +=1;
                    System.out.println("You lose!");
                    
                }
            }
            else{
                System.out.println("It's a tie.");
                
            }
            
        }
        if(score_c<score_p){
            System.out.println("Congrats! You win.");
            System.out.println("User Score: "+score_p);
            System.out.println("Computer score: "+score_c);
        }
        else{
            System.out.println("Too bad! You lose.");
            System.out.println("User Score: "+score_p);
            System.out.println("Computer score: "+score_c);
        }

    }
} 

