/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;

import java.util.ArrayList;

/**
 *
 * @author Pampam_per
 */
public class MusicBox implements SimpleQueue {
    private ArrayList<String> SongList = new ArrayList<String>();
    
    public void enqueue(Object o){
        if(o instanceof String){
            String nameSong = (String) o;
            System.out.println(nameSong+" is added in queue");
            SongList.add(nameSong);}
    }
    public void dequeue(){
        System.out.println("Now playing "+SongList.get(0));
        SongList.remove(0);
    }
    
    
}
