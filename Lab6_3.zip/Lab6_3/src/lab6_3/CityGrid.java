/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_3;

import java.util.Random;

/**
 *
 * @author Pampam_per
 */
public class CityGrid {
    private int xCoor; //เก็บพิกัดของชายผูหนึ่งในแนวแกน x
    private int yCoor; //เก็บพิกัดของชายผูหนึ่งในแนวแกน y
    private int gridSize; //เก็บขนาดของเมือง
    private static int pace=0;
    
    public CityGrid(int size){
        gridSize = size;
        xCoor = size/2;
        yCoor = size/2;
    }
    
    public void walk(){
        Random a = new Random();
        int b = a.nextInt(4);
        if(b == 0){
            xCoor += 1; //b=0 คือ x++
        }
        else if(b == 1){
            xCoor = xCoor-1; //b=1 คือ x--
        }
        else if(b == 2){
            yCoor += 1; //b=2 คือ y++
        }
        else if(b == 3){
            yCoor = yCoor-1; //b=3 คือ y--
        }
        pace++;
        //System.out.println(xCoor+" "+yCoor+" "+pace);
    
    }
    
    public boolean isInCity(){
        if(xCoor >= 0 && xCoor <= gridSize && yCoor >= 0 && yCoor <= gridSize){
            return true;
        }
        else{
            return false;
        }
        
    }
    public void reset(){
        xCoor = gridSize/2;
        yCoor = gridSize/2;
        pace = 0;
        
    }
    
    
    
    public static void main(String[] args){
        CityGrid test = new CityGrid(10);
        int step = 0,max=0;
        double sum =0;
        for(int i =0;i<10000;i++){
            
            
            for(int j = 0;j < 1000;j++){
                test.walk();
                step = pace;
                if(test.isInCity()==false){
                    
                    test.reset();
                    break;
                }
        
            }
            sum = step+sum;
            if(max<step) max = step;
            
        }
            System.out.printf("Average number of steps that a person can take and is still in the city: %.2f\n",(sum/10000));
            System.out.println("Maximum number of steps that a person can take and is still in the city: "+max);
	
    }
    
    
    /**
     * @param args the command line arguments
     */
    
    
}
