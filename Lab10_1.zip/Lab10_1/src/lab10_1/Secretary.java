/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1;

/**
 *
 * @author Pampam_per
 */
public class Secretary extends Employee{
    private int typingSpeed; //เก็บความเร็วในการพิมพ์ดีดหน่วยเป็นคำต่อนาที
    private int[] score;
    
    public Secretary(String name,int salary,int[] sc,int typingSpeed){
        super(name,salary);
        this.score = sc;
        this.typingSpeed = typingSpeed;
    }
    
    public double evaluate(){
        int sc = 0;
        for(int i = 0;i < score.length;i++){
            sc += score[i];
        }
        return sc;
    }
    
    public char grade(double sc){
        if(sc >= 90){
            this.setSalary(18000);
            return 'P';
        }
        else{
            return 'F';
        }
    }
}
