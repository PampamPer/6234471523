/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1;

/**
 *
 * @author Pampam_per
 */
public class Subject implements Evaluation{
    private String subjName; //เก็บชื่อวิชาที่จะรับการประเมินว่า คะแนนเฉลี่ยของนิสิตทั้งห้องผ่านมาตรฐานที่กำหนดหรือไม่
    private int[] score;
    
    public Subject(String subjname,int[] score){
        this.subjName = subjname;
        this.score = score;
    }
    
    public double evaluate(){
        int sc = 0;
        for(int i = 0;i < score.length;i++){
            sc += score[i];
        }
        sc = sc/score.length;
        return sc;
    }
    
    public char grade(double sc){
        if(sc >= 70){
            return 'P';
        }
        else{
            return 'F';
        }
    }
    
    public String toString(){
        return subjName;
    }
}
