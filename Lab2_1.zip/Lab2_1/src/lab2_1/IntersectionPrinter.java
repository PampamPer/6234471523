/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_1;
    import java.util.Random ;
    import java.awt.Rectangle ;
/**
 *
 * @author usci
 */
public class IntersectionPrinter { 
    public static IntersectionPrinter box = new IntersectionPrinter();
    public Rectangle Rec(){
        Random generator = new Random();
        int x = generator.nextInt(50)+1;
        int y = generator.nextInt(50)+1;
        int w = generator.nextInt(50)+1;
        int h = generator.nextInt(50)+1;
        Rectangle r = new Rectangle(x,y,w,h);
        return r ; }
    public static void main(String[] args) {
        Rectangle r1 = box.Rec() ;
        System.out.println(r1) ;
        Rectangle r2 = box.Rec() ;
        System.out.println(r2) ;
        Rectangle r3 = r1.intersection(r2);
        System.out.print("Is the intersected rectangle empty?:") ;
        System.out.println(r3.isEmpty()) ;
        
    }
    
}
