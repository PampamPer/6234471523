/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

/**
 *
 * @author usci
 */
public class PurseTester {
    public static void main(String[] args) {
        // TODO code application logic here
        Purse test = new Purse();
        Purse test2 = new Purse();
        Purse test3 = new Purse();
        
        test.addCoin("Penny");
        test.addCoin("Baht");
        test.addCoin("Yen");
        
        test2.addCoin("Yen");
        test2.addCoin("Penny");
        test2.addCoin("Baht");
        
        
        System.out.println(test.toString());
        System.out.println(test.reverse());
        test2.transfer(test3);
        System.out.println(test.sameContents(test3));
        System.out.println(test.sameCoins(test2));
        
    }
}
