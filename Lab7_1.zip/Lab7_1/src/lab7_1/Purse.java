/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

import java.util.ArrayList;
/**
 *
 * @author usci
 */
public class Purse {
    ArrayList<String> name_coin = new ArrayList<String>();
    
    
    public void addCoin(String coinName){
        name_coin.add(coinName);
    }
    public String toString(){
        if(name_coin.size() == 0){
            return "Purse[]";}
        else{
            String purse = "Purse[";
            for(int i = 1;i < name_coin.size();i++){
                purse += name_coin.get(i-1)+"," ;   
            }
            
            purse = purse+name_coin.get(name_coin.size()-1)+"]";
            return purse;
        }
        
    }
    public ArrayList<String> reverse(){
        ArrayList<String> reverse = new ArrayList<String>();
        for(int i = 0;i < name_coin.size();i++){
            reverse.add(name_coin.get(name_coin.size()-i-1));
        }
        return reverse;
    
    
    }
    public void transfer(Purse other){
        String a = this.toString();
        a = "Purse[]";
        if(other.toString()!="Purse[]"){
            String b = other.toString().replace("]",",")+this.toString().replace("Purse[","");
            System.out.println(a+"\n"+b);
        }
        else{
            String b = other.toString().replace("]","")+this.toString().replace("Purse[","");
            System.out.println(a+"\n"+b);
        }
    
    }
    public boolean sameContents(Purse other){
        
            if(this.toString().equals(other.toString())){
                return true; 
            }
            else{return false;}       
       
    }
    public boolean sameCoins(Purse other){
        if(other.name_coin.size()!=name_coin.size()){return false;}
        for(int i =0;i < name_coin.size();i++){
            if(other.name_coin.get(i).equals(name_coin.get(i))){
                return false;
                }
            
            }
       return true;
        
    }

    /**
     * @param args the command line arguments
     */
    
    
}
