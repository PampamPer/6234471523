/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_1;
/*import java.util.Scanner ; */
/**
 *
 * @author usci
 */
public class InsectPopulation {
    
    private double insectnum ;
    
    public InsectPopulation(double num){
        insectnum = num ;    
    }
    public void breed(){
        insectnum = insectnum*2 ;
    }
    public void spray(){
        insectnum = insectnum*0.9 ;
    }
    public double getNumInsect(){
        return insectnum ;
    }
    
    
    
}
