/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;

/**
 *
 * @author Pampam_per
 */
public abstract class Taylor {
    private int k;
    private double x;
    
    public int factorial(int n){ //ให้คำนวณค่า factorial ของ n
        int f=1;
        for(int i = 0;n-i>0;i++){
            f= f*(n-i); 
        }
        return f;
    }
    public void setIter(int k){ //ให้กำหนดค่าของ k จากสูตร
        this.k = k;
    }
    public int getIter(){ //เพื่อคืนค่า k
        return k;
    }
    public void setValue(double x){ //ให้กำหนดค่าของ x จากสูตร
        this.x = x;
    }
    public double getValue(){ //เพื่อคืนค่า x
        return x;
    }
    public abstract void printValue();
    public abstract double getApprox(); 
    
}
