/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

/**
 *
 * @author Pampam_per
 */
public class TimeInterval {
    private int h1,m1,h2,m2,h,m ;
    public TimeInterval(int start,int end){
        h1 = start/100*60 ;
        m1 = start%100+h1 ;
        h2 = end/100*60 ;
        m2 = end%100+h2 ;
            
    }
    public int getHours(){
        h = (m2-m1)/60 ;
        return h ;
    }
    public int getMinutes(){
        m = (m2-m1)-(h*60) ;
        return m ;
    }
    
    /**
     * @param args the command line arguments
     */
    
            
        // TODO code application logic here
    
    
}
